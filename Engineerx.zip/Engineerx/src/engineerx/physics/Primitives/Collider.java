/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package engineerx.physics.Primitives;
import java.awt.Component;
import org.joml.Vector2f;
/**
 *
 * @author ZIVBD
 */
public class Collider extends Component{
    protected Vector2f offset = new Vector2f();
}
